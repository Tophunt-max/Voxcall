import { Hono } from 'hono';
import { authMiddleware, adminMiddleware } from '../middleware/auth';
import type { Env, JWTPayload } from '../types';

const admin = new Hono<{ Bindings: Env; Variables: { user: JWTPayload } }>();
admin.use('*', authMiddleware, adminMiddleware);

// GET /api/admin/dashboard
admin.get('/dashboard', async (c) => {
  const db = c.env.DB;
  const [users, hosts, calls, revenue] = await Promise.all([
    db.prepare('SELECT COUNT(*) as count FROM users WHERE role = "user"').first<any>(),
    db.prepare('SELECT COUNT(*) as count FROM hosts').first<any>(),
    db.prepare('SELECT COUNT(*) as count FROM call_sessions WHERE DATE(created_at, "unixepoch") = DATE("now")').first<any>(),
    db.prepare('SELECT SUM(coins_charged) as total FROM call_sessions WHERE status = "ended"').first<any>(),
  ]);
  return c.json({ total_users: users?.count, total_hosts: hosts?.count, calls_today: calls?.count, total_revenue_coins: revenue?.total });
});

// GET /api/admin/users
admin.get('/users', async (c) => {
  const { page = '1', limit = '20', search } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  let q = 'SELECT id, name, email, role, coins, is_verified, created_at FROM users';
  const params: any[] = [];
  if (search) { q += ' WHERE name LIKE ? OR email LIKE ?'; params.push(`%${search}%`, `%${search}%`); }
  q += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), offset);
  const result = await db(c).prepare(q).bind(...params).all();
  return c.json(result.results);
});

function db(c: any) { return c.env.DB as D1Database; }

// PATCH /api/admin/users/:id
admin.patch('/users/:id', async (c) => {
  const { id } = c.req.param();
  const { coins, role, is_verified } = await c.req.json();
  const sets: string[] = []; const vals: any[] = [];
  if (coins !== undefined) { sets.push('coins = ?'); vals.push(coins); }
  if (role !== undefined) { sets.push('role = ?'); vals.push(role); }
  if (is_verified !== undefined) { sets.push('is_verified = ?'); vals.push(is_verified); }
  if (!sets.length) return c.json({ error: 'Nothing to update' }, 400);
  vals.push(id);
  await db(c).prepare(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

// GET /api/admin/hosts
admin.get('/hosts', async (c) => {
  const result = await db(c).prepare(
    'SELECT h.*, u.name, u.email, u.avatar_url FROM hosts h JOIN users u ON u.id = h.user_id ORDER BY h.created_at DESC'
  ).all();
  return c.json(result.results.map((h: any) => ({ ...h, specialties: JSON.parse(h.specialties || '[]'), languages: JSON.parse(h.languages || '[]') })));
});

// PATCH /api/admin/hosts/:id
admin.patch('/hosts/:id', async (c) => {
  const { id } = c.req.param();
  const { is_active, is_top_rated, identity_verified } = await c.req.json();
  const sets: string[] = []; const vals: any[] = [];
  if (is_active !== undefined) { sets.push('is_active = ?'); vals.push(is_active); }
  if (is_top_rated !== undefined) { sets.push('is_top_rated = ?'); vals.push(is_top_rated); }
  if (identity_verified !== undefined) { sets.push('identity_verified = ?'); vals.push(identity_verified); }
  vals.push(id);
  await db(c).prepare(`UPDATE hosts SET ${sets.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

// GET /api/admin/withdrawals
admin.get('/withdrawals', async (c) => {
  const result = await db(c).prepare(
    `SELECT wr.*, h.display_name, u.name, u.email FROM withdrawal_requests wr
     JOIN hosts h ON h.id = wr.host_id JOIN users u ON u.id = h.user_id
     ORDER BY wr.created_at DESC`
  ).all();
  return c.json(result.results);
});

// PATCH /api/admin/withdrawals/:id
admin.patch('/withdrawals/:id', async (c) => {
  const { id } = c.req.param();
  const { status, admin_note } = await c.req.json();
  await db(c).prepare('UPDATE withdrawal_requests SET status = ?, admin_note = ?, updated_at = unixepoch() WHERE id = ?')
    .bind(status, admin_note ?? null, id).run();
  return c.json({ success: true });
});

// GET/POST/PATCH /api/admin/coin-plans
admin.get('/coin-plans', async (c) => {
  const result = await db(c).prepare('SELECT * FROM coin_plans ORDER BY coins ASC').all();
  return c.json(result.results);
});
admin.post('/coin-plans', async (c) => {
  const { name, coins, price, bonus_coins, is_popular } = await c.req.json();
  const id = crypto.randomUUID();
  await db(c).prepare('INSERT INTO coin_plans (id, name, coins, price, bonus_coins, is_popular) VALUES (?, ?, ?, ?, ?, ?)')
    .bind(id, name, coins, price, bonus_coins ?? 0, is_popular ?? 0).run();
  return c.json({ id, success: true }, 201);
});
admin.patch('/coin-plans/:id', async (c) => {
  const { id } = c.req.param();
  const { name, coins, price, bonus_coins, is_popular, is_active } = await c.req.json();
  const sets: string[] = []; const vals: any[] = [];
  const fields = { name, coins, price, bonus_coins, is_popular, is_active };
  for (const [k, v] of Object.entries(fields)) { if (v !== undefined) { sets.push(`${k} = ?`); vals.push(v); } }
  vals.push(id);
  await db(c).prepare(`UPDATE coin_plans SET ${sets.join(', ')} WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});

// GET/PATCH app settings
admin.get('/settings', async (c) => {
  const result = await db(c).prepare('SELECT * FROM app_settings').all();
  const obj: any = {};
  result.results.forEach((r: any) => { obj[r.key] = r.value; });
  return c.json(obj);
});
admin.patch('/settings', async (c) => {
  const body = await c.req.json();
  const stmts = Object.entries(body).map(([k, v]) =>
    db(c).prepare('INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, unixepoch())').bind(k, String(v))
  );
  await db(c).batch(stmts);
  return c.json({ success: true });
});

// Talk Topics CRUD
admin.get('/talk-topics', async (c) => {
  const result = await db(c).prepare('SELECT * FROM talk_topics ORDER BY name ASC').all();
  return c.json(result.results);
});
admin.post('/talk-topics', async (c) => {
  const body = await c.req.json() as any;
  const id = 'topic-' + Date.now();
  await db(c).prepare('INSERT INTO talk_topics (id, name, icon, is_active) VALUES (?, ?, ?, 1)')
    .bind(id, body.name, body.icon || '💬').run();
  return c.json({ id, ...body });
});
admin.patch('/talk-topics/:id', async (c) => {
  const { id } = c.req.param();
  const body = await c.req.json() as any;
  const fields = Object.entries(body).map(([k]) => `${k} = ?`).join(', ');
  await db(c).prepare(`UPDATE talk_topics SET ${fields} WHERE id = ?`).bind(...Object.values(body), id).run();
  return c.json({ success: true });
});
admin.delete('/talk-topics/:id', async (c) => {
  const { id } = c.req.param();
  await db(c).prepare('DELETE FROM talk_topics WHERE id = ?').bind(id).run();
  return c.json({ success: true });
});

// Coin transactions
admin.get('/coin-transactions', async (c) => {
  const result = await db(c).prepare(`
    SELECT ct.*, u.name as user_name, u.email as user_email
    FROM coin_transactions ct
    LEFT JOIN users u ON ct.user_id = u.id
    ORDER BY ct.created_at DESC LIMIT 500
  `).all();
  return c.json(result.results);
});

// Ratings
admin.get('/ratings', async (c) => {
  const result = await db(c).prepare(`
    SELECT r.*, u.name as user_name, h.display_name as host_display_name
    FROM ratings r
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN hosts h ON r.host_id = h.id
    ORDER BY r.created_at DESC LIMIT 500
  `).all();
  return c.json(result.results);
});

// Notifications: list + send
admin.get('/notifications', async (c) => {
  const result = await db(c).prepare(`
    SELECT n.*, u.name as user_name, u.email as user_email
    FROM notifications n
    LEFT JOIN users u ON n.user_id = u.id
    ORDER BY n.created_at DESC LIMIT 500
  `).all();
  return c.json(result.results);
});
admin.post('/notifications/send', async (c) => {
  const body = await c.req.json() as any;
  const { title, body: msgBody, type = 'system', target, userId } = body;
  const now = Math.floor(Date.now() / 1000);
  let targetUsers: any[] = [];
  if (target === 'all') {
    const r = await db(c).prepare('SELECT id FROM users').all();
    targetUsers = r.results;
  } else if (target === 'hosts') {
    const r = await db(c).prepare('SELECT u.id FROM users u INNER JOIN hosts h ON h.user_id = u.id').all();
    targetUsers = r.results;
  } else if (target === 'user' && userId) {
    targetUsers = [{ id: userId }];
  }
  if (targetUsers.length === 0) return c.json({ sent: 0 });
  const stmts = targetUsers.map((u: any) => {
    const id = 'notif-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
    return db(c).prepare('INSERT INTO notifications (id, user_id, type, title, body, created_at) VALUES (?, ?, ?, ?, ?, ?)')
      .bind(id, u.id, type, title, msgBody, now);
  });
  await db(c).batch(stmts);
  return c.json({ sent: targetUsers.length });
});

// Call sessions
admin.get('/calls', async (c) => {
  const result = await db(c).prepare(`
    SELECT cs.*, 
      u.name as caller_name, u.email as caller_email,
      h.display_name as host_display_name
    FROM call_sessions cs
    LEFT JOIN users u ON cs.caller_id = u.id
    LEFT JOIN hosts h ON cs.host_id = h.id
    ORDER BY cs.created_at DESC LIMIT 200
  `).all();
  return c.json(result.results);
});

// FAQs CRUD
admin.get('/faqs', async (c) => {
  const result = await db(c).prepare('SELECT * FROM faqs ORDER BY order_index ASC, created_at ASC').all();
  return c.json(result.results);
});
admin.post('/faqs', async (c) => {
  const body = await c.req.json() as any;
  const id = 'faq-' + Date.now();
  await db(c).prepare(
    'INSERT INTO faqs (id, question, answer, order_index, is_active) VALUES (?, ?, ?, ?, 1)'
  ).bind(id, body.question, body.answer, body.order_index || 0).run();
  return c.json({ id, ...body });
});
admin.patch('/faqs/:id', async (c) => {
  const { id } = c.req.param();
  const body = await c.req.json() as any;
  const fields = Object.entries(body).map(([k]) => `${k} = ?`).join(', ');
  const vals = [...Object.values(body), id];
  await db(c).prepare(`UPDATE faqs SET ${fields}, updated_at = unixepoch() WHERE id = ?`).bind(...vals).run();
  return c.json({ success: true });
});
admin.delete('/faqs/:id', async (c) => {
  const { id } = c.req.param();
  await db(c).prepare('DELETE FROM faqs WHERE id = ?').bind(id).run();
  return c.json({ success: true });
});

export default admin;

